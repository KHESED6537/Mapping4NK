package com.mercy.data_analysis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataAnalysisApplicationTests {

	@Test
	void contextLoads() {
	}

}
